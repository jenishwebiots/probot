class ApiConfig {
  static String chatGPTkey =
      "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";


  static bool isads = false;

  static int limit = 5;
}

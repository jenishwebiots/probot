class Session {
  String isGuestLogin = 'isGuestLogin';
  String selectedCharacter = 'selectedCharacter';
  String isLogin = 'isLogin';
  String isBiometric = 'isBiometric';
  String isLanguage = 'isLanguage';
  String isCharacter = 'isCharacter';
  String isDarkMode = 'isDarkMode';
  String characterIndex = 'characterIndex';
  String locale = 'locale';
  String envConfig = 'envConfig';
  String firebaseConfig = 'firebaseConfig';
}
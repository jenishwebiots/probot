class AppFonts {
// On boarding page fonts
  String chatGpt = "chatGpt";
  String skip = "skip";
  String chatWith = "chatWith";
  String openAiChatGpt = "openAiChatGpt";
  String easilyGenerateImage = "easilyGenerateImage";
  String toReceiveTheFinest = "toReceiveTheFinest";
  String quickCreation = "quickCreation";
  String enterTheTitle = "enterTheTitle";

  String quickAnswerFor = "quickAnswerFor";
  String aBuddyWhoAvailable = "aBuddyWhoAvailable";
  String signIn = "signIn";
  String signUp = "signUp";
  String or = "or";
  String continueAsAGuest = "continueAsAGuest";
  String proBot = "proBot";
  String fastResponse = "fastResponse";

  String welcomeBack = "welcomeBack";
  String fillTheBelow = "fillTheBelow";
  String email = "email";
  String enterEmail = "enterEmail";
  String password = "password";
  String enterPassword = "enterPassword";
  String resetPassword = "resetPassword";
  String dontHaveAnAccount = "dontHaveAnAccount";
  String continueWithGoogle = "continueWithGoogle";
  String simplyUseThis = "simplyUseThis";
  String enterYourMailOr = "enterYourMailOr";

  String changePassword = "changePassword";
  String dontUseOneOf = "dontUseOneOf";
  String newPassword = "newPassword";
  String confirmPassword = "confirmPassword";
  String reEnterPassword = "reEnterPassword";
  String updatePassword = "updatePassword";
  String alreadyHaveAnAccount = "alreadyHaveAnAccount";
  String createANewAccount = "createANewAccount";
  String emailAlreadyUse = "emailAlreadyUse";
  String unknownError = "unknownError";
  String pleaseEnterEmail = "pleaseEnterEmail";
  String pleaseEnterValid = "pleaseEnterValid";
  String pleaseEnterPassword = "pleaseEnterPassword";
  String passwordMustBe = "passwordMustBe";
  String passwordNotSame = "passwordNotSame";
  String wrongPassword = "wrongPassword";
  String userNotFound = "userNotFound";
  String emailSend = "emailSend";

  String selectLanguage = "selectLanguage";
  String youCanChangeIt = "youCanChangeIt";
  String english = "english";
  String french = "french";
  String italian = "italian";
  String japanese = "japanese";
  String german = "german";
  String hindi = "hindi";
  String continues = "continues";

  String selectCharacter = "selectCharacter";
  String dino = "dino";
  String king = "king";
  String dolly = "dolly";
  String kettie = "kettie";
  String marvel = "marvel";
  String henny = "henny";
  String slophie = "slophie";
  String setupAFingerprint = "setupAFingerprint";
  String addNow = "addNow";
  String doItLater = "doItLater";

  String chooseOption = "chooseOption";
  String darkTheme = "darkTheme";
  String listCharacter = "listCharacter";
  String tapCharacter = "tapCharacter";
  String chatWithProBot = "chatWithProBot";
}

class GifAssets {
  final String fingerprint = "assets/gif/fingerprint.gif";
  final String loading = "assets/gif/loading.gif";
  final String loader = "assets/gif/loader.gif";

}

class GifAssets {
}

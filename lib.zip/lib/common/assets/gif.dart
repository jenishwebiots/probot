class GifAssets {
  final String fingerprint = "assets/gif/fingerprint.gif";
  final String loading = "assets/gif/loading.gif";
  final String loader = "assets/gif/loader.gif";
  final String coin = "assets/gif/coin.gif";
  final String coinDark = "assets/gif/coinDark.gif";

}

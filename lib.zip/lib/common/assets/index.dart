import 'package:probot/common/assets/svg_assets.dart';
import 'gif.dart';
import 'image_assets.dart';

ImageAssets eImageAssets = ImageAssets();
SvgAssets eSvgAssets = SvgAssets();
GifAssets eGifAssets = GifAssets();








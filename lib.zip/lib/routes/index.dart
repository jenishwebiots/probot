import 'package:probot/routes/route_method.dart';
import 'package:probot/routes/route_name.dart';

RouteName routeName = RouteName();
AppRoute appRoute = AppRoute();

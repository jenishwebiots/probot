

import '../../config.dart';

class PrivacyPolicyController extends GetxController {

}
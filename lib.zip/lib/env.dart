Map<String, dynamic> environment = {
  "chatTextCount":20,
  "imageCount":10,
  "textCompletionCount":20,
  "isChatShow": true,
  "isImageGeneratorShow": true,
  "isTextCompletionShow": true,
  "bannerAddId": "ca-app-pub-3940256099942544/6300978111",

};
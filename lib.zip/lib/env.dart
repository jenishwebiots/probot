Map<String, dynamic> environment = {
  "chatTextCount": "5",
  "imageCount": "5",
  "textCompletionCount": "5",
};
